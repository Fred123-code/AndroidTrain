#ifndef FFMPEGANDROID_FFPROBE_H
#define FFMPEGANDROID_FFPROBE_H

int ffprobe_run(int argc, char **argv);

#endif //FFMPEGANDROID_FFPROBE_H
